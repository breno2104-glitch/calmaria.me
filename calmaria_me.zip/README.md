# Calmaria.me — Protótipo estático

Este pacote contém as páginas estáticas do Calmaria.me.

## Publicar no GitHub Pages
1. Crie o repositório `calmaria.me` (público).
2. Envie todos os arquivos deste ZIP para a raiz do repositório.
3. Em **Settings → Pages** selecione **Deploy from a branch**, depois **Branch: main** e **Folder: /(root)** e salve.
4. Acesse: `https://SEU-USUARIO.github.io/calmaria.me` (troque pelo seu usuário).

Arquivos:
- `index.html` — Home
- `calma.html` — “Preciso de calma agora”
- `diario.html` — Diário emocional (evapora o texto)
- `teste.html` — Teste rápido de estresse (5 perguntas)
- `premium.html` — Planos de assinatura
- `assets/style.css` — Estilos compartilhados
- `assets/app.js` — Scripts simples
